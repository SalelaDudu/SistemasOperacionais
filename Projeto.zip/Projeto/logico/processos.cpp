#include "cabecalhos/processos.h"

using namespace std;

Processos(){
}

void inicio(Processos& a,int prioridadee, int n_entradaa)
{
    a.etapa_atual = 0;
    this.flags += "Iniciou";
    prioridade = prioridadee;
    this->n_entrada = n_entrada;
}

void avanca_etapa()
{
    this.etapa_atual ++;
    this.flags += " ExecutouAgora"
}
