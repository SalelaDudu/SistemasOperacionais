// protótipos do processo
#ifndef processos_h
#define processos_h

namespace std
{
    class Processos
    {
        public:
            // Definição de váriavies
            char* name;
            int total_etapas;
            int etapa_atual;
            char* flags;
            int prioridade;
            int n_entrada;
            // Métodos
            Processos(){};
            void inicio(Processos& a,int prioridadee, int n_entradaa){};
            void avanca_etapa(){};
            void fim_processo(){};

                
        private:
            // Métodos

    };
}

#endif