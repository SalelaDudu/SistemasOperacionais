#include <iostream>
#include "cabecalhos/processos.h"

using namespace std;

int main(int argc, char* argv[])
{
    Processos chrome;
    Processos* bla = &chrome;
    
    chrome.name = "Google";
    chrome.etapa_atual = 2;

    cout << chrome.name << endl << chrome.etapa_atual << endl << chrome.n_entrada << endl << chrome.prioridade << endl << endl;

    chrome.inicio(chrome,1,1);

    cout << "Rodou inicio" << endl << endl;

    cout << chrome.name << endl << chrome.etapa_atual << endl << chrome.n_entrada << endl << chrome.prioridade <<endl;
  
    return 0;
}